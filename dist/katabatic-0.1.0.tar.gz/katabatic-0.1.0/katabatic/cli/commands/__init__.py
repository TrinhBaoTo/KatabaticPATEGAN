from .model_init import init_model

__all__ = ["init_model"]